-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2021 at 05:12 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `schoolmgt`
--

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `id` int(15) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dob` varchar(25) NOT NULL,
  `stdin` int(3) NOT NULL,
  `gen` varchar(25) NOT NULL,
  `mobino` bigint(15) NOT NULL,
  `DofAdd` varchar(25) NOT NULL,
  `address` varchar(100) NOT NULL,
  `fees` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`id`, `name`, `dob`, `stdin`, `gen`, `mobino`, `DofAdd`, `address`, `fees`) VALUES
(1, 'mobile', '12-6-2021', 1, 'male', 6565656565, '45-5-2021', 'asdmbasjdasdasd\r\nasd\r\nasd\r\nasd', 'paid'),
(2, 'whatsapp', '17-08-2017', 2, 'female', 98989898, '19-08-2021', 'asdasd\nas\nd\nasd\nas\nd', 'paid'),
(3, 'facebook', '09-08-2014', 3, 'male', 878465151, '07-08-2021', 'sfsdf\nsd\nf\nsd\nf\nsdf', 'unpaid'),
(4, 'Sharchat', '08-08-2015', 4, 'male', 9876543215, '11-08-2021', 'sfdsdfsdfsdf\nsdf\nsd\nf', 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` mediumint(3) NOT NULL,
  `uname` varchar(15) NOT NULL,
  `pwd` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `uname`, `pwd`) VALUES
(1, 'admin1', '12345'),
(2, 'admin2', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
