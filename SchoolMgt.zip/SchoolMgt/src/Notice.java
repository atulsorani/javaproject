import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.MatteBorder;

public class Notice {

	private JFrame notice;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Notice window = new Notice();
					window.notice.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Notice() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		notice = new JFrame();
		notice.setTitle("Create Notice");
		notice.setBounds(100, 100, 1400, 867);
		notice.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		notice.setResizable(false);
		notice.setLocationRelativeTo(null);
		notice.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(12, 13, 1358, 794);
		notice.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(102, 205, 170));
		panel_1.setBounds(0, 0, 1358, 59);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel txthead = new JLabel("Notice");
		txthead.setFont(new Font("SansSerif", Font.BOLD, 30));
		txthead.setForeground(Color.WHITE);
		txthead.setBounds(637, 13, 476, 33);
		panel_1.add(txthead);
	}

}
