import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.MatteBorder;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import com.toedter.calendar.JDateChooser;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import java.awt.SystemColor;
import java.awt.Button;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.ButtonGroup;

public class StudUpdate {

	private JFrame studUpdate;
	private JTextField txtid;
	private JTextField txtname;
	private JTextField txtmno;
	private ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void StartStudUpdate() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudUpdate window = new StudUpdate();
					window.studUpdate.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudUpdate() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		studUpdate = new JFrame();
		studUpdate.setBounds(100, 100, 1400, 867);
		studUpdate.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		studUpdate.setResizable(false);
		studUpdate.setLocationRelativeTo(null);
		studUpdate.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(12, 13, 1358, 794);
		studUpdate.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(102, 205, 170));
		panel_1.setBounds(0, 0, 1358, 59);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblUpdateStudentsRecords = new JLabel("Update Student's Records");
		lblUpdateStudentsRecords.setFont(new Font("SansSerif", Font.BOLD, 30));
		lblUpdateStudentsRecords.setForeground(Color.WHITE);
		lblUpdateStudentsRecords.setBounds(510, 13, 476, 33);
		panel_1.add(lblUpdateStudentsRecords);
		
		txtid = new JTextField();
		txtid.setFont(new Font("Verdana", Font.PLAIN, 17));
		txtid.setColumns(10);
		txtid.setBounds(609, 86, 284, 34);
		panel.add(txtid);
		
		JLabel label = new JLabel("I'd");
		label.setForeground(Color.BLACK);
		label.setFont(new Font("Verdana", Font.PLAIN, 17));
		label.setBounds(490, 95, 56, 16);
		panel.add(label);
		
		txtname = new JTextField();
		txtname.setFont(new Font("Verdana", Font.PLAIN, 17));
		txtname.setColumns(10);
		txtname.setBounds(609, 149, 284, 34);
		panel.add(txtname);
		
		JLabel label_1 = new JLabel("Name");
		label_1.setFont(new Font("Verdana", Font.PLAIN, 17));
		label_1.setBounds(490, 155, 56, 16);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("DOB");
		label_2.setFont(new Font("Verdana", Font.PLAIN, 17));
		label_2.setBounds(490, 229, 56, 16);
		panel.add(label_2);
		
		JDateChooser txtdate = new JDateChooser();
		txtdate.setBounds(609, 221, 284, 34);
		panel.add(txtdate);
		
		JDateChooser addDate = new JDateChooser();
		addDate.setBounds(609, 372, 284, 34);
		panel.add(addDate);
		
		JComboBox<String> stdin = new JComboBox<String>();
		stdin.setModel(new DefaultComboBoxModel<String>(new String[] {"Select your class", "1", "2", "3", "4", "5", "6", "7", "8"}));
		stdin.setFont(new Font("Verdana", Font.PLAIN, 17));
		stdin.setBounds(609, 300, 284, 34);
		panel.add(stdin);
		
		JLabel label_3 = new JLabel("Admission in");
		label_3.setFont(new Font("Verdana", Font.PLAIN, 16));
		label_3.setBounds(490, 299, 107, 32);
		panel.add(label_3);
		
		JLabel label_4 = new JLabel("Gender");
		label_4.setFont(new Font("Verdana", Font.PLAIN, 17));
		label_4.setBounds(490, 453, 84, 22);
		panel.add(label_4);
		
		JRadioButton txtmalee = new JRadioButton("MALE");
		buttonGroup.add(txtmalee);
		txtmalee.setFont(new Font("Tahoma", Font.PLAIN, 17));
		txtmalee.setBounds(609, 447, 107, 34);
		panel.add(txtmalee);
		
		JRadioButton txtfemalee = new JRadioButton("FEMALE");
		buttonGroup.add(txtfemalee);
		txtfemalee.setFont(new Font("Tahoma", Font.PLAIN, 17));
		txtfemalee.setBounds(786, 447, 107, 34);
		panel.add(txtfemalee);
		
		txtmno = new JTextField();
		txtmno.setFont(new Font("Verdana", Font.PLAIN, 17));
		txtmno.setColumns(10);
		txtmno.setBounds(609, 520, 284, 34);
		panel.add(txtmno);
		
		JLabel label_5 = new JLabel("Mobile No");
		label_5.setFont(new Font("Verdana", Font.PLAIN, 17));
		label_5.setBounds(490, 520, 107, 34);
		panel.add(label_5);
		
		JTextArea address = new JTextArea();
		address.setRows(3);
		address.setForeground(Color.BLACK);
		address.setFont(new Font("Verdana", Font.PLAIN, 17));
		address.setBackground(SystemColor.controlHighlight);
		address.setBounds(609, 581, 284, 93);
		panel.add(address);
		
		JLabel label_7 = new JLabel("Address");
		label_7.setFont(new Font("Verdana", Font.PLAIN, 17));
		label_7.setBounds(490, 577, 84, 27);
		panel.add(label_7);
		
		Button button = new Button("Update Record");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String idd = txtid.getText();
				try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgt","root","");
					String sqll = "UPDATE `admission` SET `id`=?,`name`=?,`dob`=?,`stdin`=?,`gen`=?,`mobino`=?,`DofAdd`=?,`address`=? WHERE id = '"+idd+"'";
					PreparedStatement st=con.prepareStatement(sqll);
					
					st.setString(1, txtid.getText());
					st.setString(2, txtname.getText());

					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					String date1 = sdf.format(txtdate.getDate());
					st.setString(3, date1);
					
					String val = stdin.getSelectedItem().toString();
					st.setString(4, val);
					
							String gen = null;
						if(txtmalee.isSelected()) {
							 gen = "male";
						}
						else
						{
							gen = "female";
						}
						st.setString(5, gen);
					
						st.setString(6, txtmno.getText());
						
						
						SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
						String date11 = sdf1.format(addDate.getDate());
						st.setString(7, date11);
						
						st.setString(8, address.getText());
						st.executeUpdate();
						
						
						JOptionPane.showMessageDialog(null, "Record Updated......");
				
					
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
			}
			}
		});
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Verdana", Font.PLAIN, 20));
		button.setBackground(new Color(100, 149, 237));
		button.setBounds(906, 728, 163, 43);
		panel.add(button);
		
		Button button_1 = new Button("Cancel");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			System.exit(0);
			}
		});
		button_1.setForeground(Color.WHITE);
		button_1.setFont(new Font("Verdana", Font.PLAIN, 20));
		button_1.setBackground(new Color(255, 20, 147));
		button_1.setBounds(373, 728, 143, 43);
		panel.add(button_1);
		
		JButton btnGiveId = new JButton("Get Records");
		btnGiveId.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String idd = txtid.getText();
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgt","root","");
					Statement st=con.createStatement();
					String sql ="SELECT `id`, `name`, `dob`, `stdin`, `gen`, `mobino`, `DofAdd`, `address` FROM `admission` WHERE id = '"+idd+"'";
					ResultSet rs = st.executeQuery(sql);
					if(rs.next()) {
						txtid.setText(rs.getString(1));
						
						txtname.setText(rs.getString(2));
										
						txtdate.setDate(rs.getDate(3));
					
						stdin.setSelectedItem(rs.getString(4));
						
						String gen = rs.getString(5);
						
						if(gen.equals("male"))
						{
							txtmalee.setSelected(true);
							txtfemalee.setSelected(false);
							
						}
						else
						{
							txtfemalee.setSelected(true);
							txtmalee.setSelected(false);
						}
						
						
						
						txtmno.setText(rs.getString(6));
						
						addDate.setDate(rs.getDate(7));
		
						address.setText(rs.getString(8));
					}
					
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
		});
		btnGiveId.setBounds(1000, 86, 128, 34);
		panel.add(btnGiveId);
		
		JLabel label_6 = new JLabel("Admission");
		label_6.setFont(new Font("Verdana", Font.PLAIN, 17));
		label_6.setBounds(490, 369, 97, 22);
		panel.add(label_6);
		
		JLabel label_8 = new JLabel("Date");
		label_8.setFont(new Font("Tahoma", Font.PLAIN, 17));
		label_8.setBounds(541, 390, 56, 16);
		panel.add(label_8);
	}
}
