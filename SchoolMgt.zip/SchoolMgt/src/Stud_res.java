import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.MatteBorder;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Stud_res {

	private JFrame studrs;
	private JTextField textnm;
	private JTextField textstd;
	private JTextField guj;
	private JTextField eng;
	private JTextField acc;
	private JTextField state;
	private JTextField ba;
	private JTextField eco;
	private JTextField sp;

	/**
	 * Launch the application.
	 */
	public static void Startstud_res() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Stud_res window = new Stud_res();
					window.studrs.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Stud_res() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		studrs = new JFrame();
		studrs = new JFrame();
		studrs.setTitle("Student Result");
		studrs.setBounds(100, 100, 1400, 867);
		studrs.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		studrs.setResizable(false);
		studrs.setLocationRelativeTo(null);
		studrs.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(12, 13, 1358, 794);
		studrs.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 1358, 59);
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(102, 205, 170));
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel txthead = new JLabel("Set Results");
		txthead.setFont(new Font("SansSerif", Font.BOLD, 30));
		txthead.setForeground(Color.WHITE);
		txthead.setBounds(605, 13, 476, 33);
		panel_1.add(txthead);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 72, 660, 709);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel txtnm = new JLabel("Name");
		txtnm.setFont(new Font("Verdana", Font.PLAIN, 16));
		txtnm.setBounds(31, 26, 56, 16);
		panel_2.add(txtnm);
		
		JLabel lblStd = new JLabel("std");
		lblStd.setFont(new Font("Verdana", Font.PLAIN, 16));
		lblStd.setBounds(433, 26, 56, 16);
		panel_2.add(lblStd);
		
		textnm = new JTextField();
		textnm.setEditable(false);
		textnm.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
		textnm.setBounds(88, 19, 260, 34);
		panel_2.add(textnm);
		textnm.setColumns(10);
		
		textstd = new JTextField();
		textstd.setEditable(false);
		textstd.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
		textstd.setColumns(10);
		textstd.setBounds(486, 19, 92, 34);
		panel_2.add(textstd);
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgt","root","");
			Statement st=con.createStatement();
			String sql ="SELECT `name`, `stdin` FROM `admission` WHERE id = '"+StudResult.iddd+"'";
			ResultSet rs = st.executeQuery(sql);
			if(rs.next()) {
				textnm.setText(rs.getString(1));
				textstd.setText(rs.getString(2));
			}
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		JLabel lblGujarati = new JLabel("GUJARATI");
		lblGujarati.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lblGujarati.setBounds(184, 136, 107, 34);
		panel_2.add(lblGujarati);
		
		JLabel lblEnglish = new JLabel("ENGLISH");
		lblEnglish.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lblEnglish.setBounds(184, 197, 107, 34);
		panel_2.add(lblEnglish);
		
		JLabel lblAccount = new JLabel("ACCOUNT");
		lblAccount.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lblAccount.setBounds(184, 255, 107, 34);
		panel_2.add(lblAccount);
		
		JLabel lblState = new JLabel("STATE");
		lblState.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lblState.setBounds(184, 317, 107, 34);
		panel_2.add(lblState);
		
		JLabel lblBa = new JLabel("BA");
		lblBa.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lblBa.setBounds(184, 382, 107, 34);
		panel_2.add(lblBa);
		
		JLabel lblEcconomics = new JLabel("ECCONOMICS");
		lblEcconomics.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lblEcconomics.setBounds(184, 456, 107, 34);
		panel_2.add(lblEcconomics);
		
		JTextArea txtrs = new JTextArea();
		txtrs.setBounds(694, 72, 652, 709);
		txtrs.setFont(new Font("Sitka Display", Font.PLAIN, 13));
		txtrs.setBackground(new Color(255, 250, 205));
		panel.add(txtrs);
		
		JLabel lblSp = new JLabel("SP");
		lblSp.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lblSp.setBounds(184, 519, 107, 34);
		panel_2.add(lblSp);
		

		guj = new JTextField();
		guj.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		guj.setBounds(303, 134, 137, 39);
		panel_2.add(guj);
		guj.setColumns(10);
		
		eng = new JTextField();
		eng.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		eng.setColumns(10);
		eng.setBounds(303, 195, 137, 39);
		panel_2.add(eng);
		
		acc = new JTextField();
		acc.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		acc.setColumns(10);
		acc.setBounds(303, 253, 137, 39);
		panel_2.add(acc);
		
		state = new JTextField();
		state.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		state.setColumns(10);
		state.setBounds(303, 315, 137, 39);
		panel_2.add(state);
		
		ba = new JTextField();
		ba.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		ba.setColumns(10);
		ba.setBounds(303, 380, 137, 39);
		panel_2.add(ba);
		
		eco = new JTextField();
		eco.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		eco.setColumns(10);
		eco.setBounds(303, 454, 137, 39);
		panel_2.add(eco);
		
		sp = new JTextField();
		sp.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		sp.setColumns(10);
		sp.setBounds(303, 517, 137, 39);
		panel_2.add(sp);
		
		
		Button btnrs = new Button("RESULT");
		btnrs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int g = Integer.parseInt(guj.getText());
				int e = Integer.parseInt(eng.getText());
				int a = Integer.parseInt(acc.getText());
				int s = Integer.parseInt(state.getText());
				int b = Integer.parseInt(ba.getText());
				int ec = Integer.parseInt(eco.getText());
				int spp = Integer.parseInt(sp.getText());
				
				String res;
				if(g>33 && e>33 && a>33 && s>33 && b>33 && ec>33 && spp>33)
				{
					 res = "PASS";
				}
				else
				{
					res = "FAIL";
				}
				
				int tot = g + e + a + s + b + ec + spp;
				int av = tot/7;
				
				txtrs.append("\t\t STEP TO SUCCESS SCHOOL \n\n\n" +
					"\t" + "NAME : " + textnm.getText() + "\t" +
					"\t" + "STD : " + textstd.getText() +
				
				"\t\t" + "\n\n ==============================================================\n\n\n" + 
				"\t" + "GUJARATI : \t\t\t" + guj.getText() + "\n\n" +
				"\t" + "ENDLISH : \t\t\t" + eng.getText() + "\n\n" +
				"\t" + "ACCOUNT : \t\t\t" + acc.getText() + "\n\n" +
				"\t" + "STATE : \t\t\t" + state.getText() + "\n\n" +
				"\t" + "BA : \t\t\t" + ba.getText() + "\n\n" +
				"\t" + "ECCONOMICS : \t\t" + eco.getText() + "\n\n" +
				"\t" + "SP : \t\t\t" + sp.getText() + "\n\n" +
				"\t\t" + "\n __________________________________________________________________\n\n\n" +
				"\t" + "TOTAL : \t\t\t" + tot + "\n\n" +
				"\t" + "AVERAGE : \t\t\t" + av + "\n\n" +
				"\t" + "RESULT : \t\t\t" + res + "\n\n" 				
				);
			}
		
		});
		btnrs.setForeground(Color.WHITE);
		btnrs.setBackground(Color.GRAY);
		btnrs.setBounds(54, 607, 128, 39);
		panel_2.add(btnrs);
		
		Button btnprnt = new Button("PRINT");
		btnprnt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					txtrs.print();
				} catch (PrinterException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnprnt.setForeground(Color.WHITE);
		btnprnt.setBackground(Color.GRAY);
		btnprnt.setBounds(426, 607, 128, 39);
		panel_2.add(btnprnt);
		
		
	}
}
