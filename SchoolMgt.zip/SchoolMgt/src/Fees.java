import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.MatteBorder;
import javax.swing.JTextField;
import java.awt.Button;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Fees {

	private JFrame Fees;
	private JTextField tf;
	private JTextField cf;
	private JTextField lf;
	private JTextField txtidd;
	private JTextField textnm;
	private JTextField stdinn;
	private JTextField ef;
	private JTextField of;
	private JTextField etf;

	/**
	 * Launch the application.
	 */
	public static void Startfees() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Fees window = new Fees();
					window.Fees.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Fees() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Fees = new JFrame();
		Fees.setTitle("Student Fees");
		Fees.setBounds(100, 100, 1400, 867);
		Fees.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		Fees.setResizable(false);
		Fees.setLocationRelativeTo(null);
		Fees.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(12, 13, 1358, 794);
		Fees.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(102, 205, 170));
		panel_1.setBounds(0, 0, 1358, 59);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel txthead = new JLabel("Fees");
		txthead.setFont(new Font("SansSerif", Font.BOLD, 30));
		txthead.setForeground(Color.WHITE);
		txthead.setBounds(651, 13, 476, 33);
		panel_1.add(txthead);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBounds(10, 72, 660, 709);
		panel.add(panel_2);
		
		JLabel lblId = new JLabel("Id");
		lblId.setFont(new Font("Verdana", Font.PLAIN, 16));
		lblId.setBounds(249, 22, 56, 16);
		panel_2.add(lblId);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Verdana", Font.PLAIN, 16));
		lblName.setBounds(48, 94, 56, 16);
		panel_2.add(lblName);
		
		JLabel lblTuitionFees = new JLabel("TUITION FEES");
		lblTuitionFees.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lblTuitionFees.setBounds(175, 187, 107, 34);
		panel_2.add(lblTuitionFees);
		
		JLabel lblComputerPracticalFees = new JLabel("COMPUTER FEES");
		lblComputerPracticalFees.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lblComputerPracticalFees.setBounds(175, 261, 151, 34);
		panel_2.add(lblComputerPracticalFees);
		
		JLabel lblLibraryFees = new JLabel("LIBRARY FEES");
		lblLibraryFees.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lblLibraryFees.setBounds(175, 324, 107, 34);
		panel_2.add(lblLibraryFees);
		
		tf = new JTextField();
		tf.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		tf.setColumns(10);
		tf.setBounds(374, 182, 137, 39);
		panel_2.add(tf);
		
		cf = new JTextField();
		cf.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		cf.setColumns(10);
		cf.setBounds(374, 256, 137, 39);
		panel_2.add(cf);
		
		lf = new JTextField();
		lf.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lf.setColumns(10);
		lf.setBounds(374, 319, 137, 39);
		panel_2.add(lf);
		
		
		txtidd = new JTextField();
		txtidd.setFont(new Font("Verdana", Font.PLAIN, 15));
		txtidd.setBounds(278, 13, 122, 39);
		panel_2.add(txtidd);
		txtidd.setColumns(10);
		
		textnm = new JTextField();
		textnm.setForeground(Color.BLACK);
		textnm.setFont(new Font("Verdana", Font.BOLD, 15));
		textnm.setBounds(116, 87, 210, 35);
		panel_2.add(textnm);
		textnm.setColumns(10);
		
		JLabel lblStd = new JLabel("Std");
		lblStd.setFont(new Font("Verdana", Font.PLAIN, 16));
		lblStd.setBounds(438, 94, 56, 16);
		panel_2.add(lblStd);
		
		stdinn = new JTextField();
		stdinn.setForeground(Color.BLACK);
		stdinn.setFont(new Font("Verdana", Font.BOLD, 15));
		stdinn.setColumns(10);
		stdinn.setBounds(488, 85, 122, 39);
		panel_2.add(stdinn);
		
		
		
		JButton btndetail = new JButton("Get Details");
		btndetail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String idd = txtidd.getText();				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgt","root","");
					Statement st=con.createStatement();
					String sql ="SELECT `name`, `stdin` FROM `admission` WHERE id = '"+idd+"'";
					ResultSet rs = st.executeQuery(sql);
					if(rs.next())
					{
						textnm.setText(rs.getString(1));
						stdinn.setText(rs.getString(2));
					}
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}
		});
		btndetail.setFont(new Font("Verdana", Font.PLAIN, 13));
		btndetail.setBounds(446, 20, 108, 32);
		panel_2.add(btndetail);
		
		JLabel lblExaminationFees = new JLabel("EXAMINATION FEES");
		lblExaminationFees.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lblExaminationFees.setBounds(175, 388, 151, 34);
		panel_2.add(lblExaminationFees);
		
		ef = new JTextField();
		ef.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		ef.setColumns(10);
		ef.setBounds(374, 383, 137, 39);
		panel_2.add(ef);
		
		of = new JTextField();
		of.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		of.setColumns(10);
		of.setBounds(374, 457, 137, 39);
		panel_2.add(of);
		
		JLabel lblOtherFees = new JLabel("OTHER FEES");
		lblOtherFees.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lblOtherFees.setBounds(175, 462, 107, 34);
		panel_2.add(lblOtherFees);
		
		etf = new JTextField();
		etf.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		etf.setColumns(10);
		etf.setBounds(374, 520, 137, 39);
		panel_2.add(etf);
		
		JLabel lblExtraTuitionFees = new JLabel("EXTRA TUITION FEES");
		lblExtraTuitionFees.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
		lblExtraTuitionFees.setBounds(175, 525, 161, 34);
		panel_2.add(lblExtraTuitionFees);
		
		JTextArea txtfees = new JTextArea();
		txtfees.setFont(new Font("Sitka Display", Font.PLAIN, 13));
		txtfees.setBackground(new Color(255, 250, 205));
		txtfees.setBounds(694, 72, 652, 709);
		panel.add(txtfees);
		
		Button btnfees = new Button("FEES");
		btnfees.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int tff = Integer.parseInt(tf.getText());
				int cff = Integer.parseInt(cf.getText());
				int lff = Integer.parseInt(lf.getText());
				int eff = Integer.parseInt(ef.getText());
				int off = Integer.parseInt(of.getText());
				int etff = Integer.parseInt(etf.getText());
				
				int tot = tff + cff + lff + eff + off + etff;
				
				txtfees.append("\t\t STEP TO SUCCESS SCHOOL \n\n\n" +
						"\t" + "NAME : " + textnm.getText() + "\t" +
						"\t" + "STD : " + stdinn.getText() + "\t \n\n" +
						"\t\t" + "FEES RECIEPT " +
					
					"\t\t" + "\n\n ==============================================================\n\n\n" + 
					"\t" + "TUITION FEES : \t\t\t" + tf.getText() + "\n\n" +
					"\t" + "COMPUTER FEES : \t\t\t" + cf.getText() + "\n\n" +
					"\t" + "LIBRARY : \t\t\t\t" + lf.getText() + "\n\n" +
					"\t" + "EXAMINATION FEES : \t\t\t" + ef.getText() + "\n\n" +
					"\t" + "OTHER FEES : \t\t\t\t" + of.getText() + "\n\n" +
					"\t" + "EXTRA TUITION FEES : \t\t\t" + etf.getText() + "\n\n" +
					"\t\t" + "\n ____________________________________________________________________________\n\n\n" +
					"\t" + "TOTAL : \t\t\t\t" + tot + "\n\n"
					);
			}
		});
		btnfees.setForeground(Color.WHITE);
		btnfees.setBackground(Color.GRAY);
		btnfees.setBounds(54, 607, 128, 39);
		panel_2.add(btnfees);
		
		
		
		Button btnprint = new Button("PRINT");		
		btnprint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String iddd = txtidd.getText();
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgt","root","");
					String sqll = "UPDATE `admission` SET `fees` = 'paid' WHERE id = '"+iddd+"'";
					PreparedStatement st=con.prepareStatement(sqll);
					st.executeUpdate();
					JOptionPane.showMessageDialog(null, "Database Updated....");
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}				
				
				
				try {
					txtfees.print();
				} catch (PrinterException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnprint.setForeground(Color.WHITE);
		btnprint.setBackground(Color.GRAY);
		btnprint.setBounds(426, 607, 128, 39);
		panel_2.add(btnprint);
		
	}
}
