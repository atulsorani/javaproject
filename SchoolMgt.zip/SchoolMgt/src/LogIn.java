import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import java.awt.Button;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LogIn {

	private JFrame frmLogIn;
	private JTextField uname;
	private JPasswordField pwd;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LogIn window = new LogIn();
					window.frmLogIn.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LogIn() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmLogIn = new JFrame();
		frmLogIn.setTitle("Log In");
		frmLogIn.setBounds(-15, -73, 1400, 867);
		frmLogIn.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmLogIn.getContentPane().setLayout(null);
		frmLogIn.setLocationRelativeTo(null);
		frmLogIn.setResizable(false);		
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(102, 205, 170));
		panel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		panel.setBounds(12, 13, 1358, 794);
		frmLogIn.getContentPane().add(panel);
		panel.setLayout(null);
		
		Button button = new Button("LogIn");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				Color clr = new Color(50,50,100);
				button.setBackground(clr);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				Color clr = new Color(100,149,237);
				button.setBackground(clr);
			}
		});
		button.setBounds(730, 513, 179, 48);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String un = uname.getText();
				@SuppressWarnings("deprecation")
				String passw = pwd.getText();
				
				
				try {					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgt","root","");
					Statement st=con.createStatement();
					String sql ="select * from login where uname='"+un+"' and pwd='"+passw+"'";
					ResultSet rs = st.executeQuery(sql);
					
					if(rs.next()) {
						//JOptionPane.showMessageDialog(null, "Login");
						frmLogIn.setVisible(false);
						home.Starthome();
					}
					else {
						JOptionPane.showMessageDialog(null, "Invalid Username and password ....!");
						uname.setText(null);
						pwd.setText(null);
						uname.requestFocus();
					}
										
				} catch (SQLException e) {
					
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					
					e.printStackTrace();
				}
			}
		});
		button.setCursor(new Cursor(Cursor.HAND_CURSOR));
		button.setFont(new Font("Dialog", Font.PLAIN, 20));
		button.setForeground(new Color(255, 255, 255));
		button.setBackground(new Color(100, 149, 237));
		panel.add(button);
		
		uname = new JTextField();
		uname.setBounds(847, 275, 262, 42);
		uname.setFont(new Font("Tahoma", Font.PLAIN, 17));
		panel.add(uname);
		uname.setColumns(10);
		
		pwd = new JPasswordField();
		pwd.setBounds(847, 385, 262, 45);
		panel.add(pwd);
		
		
		Button button_1 = new Button("Cancel");
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				Color clr = new Color(100,10,20);
				button_1.setBackground(clr);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				Color clr = new Color(255,51,153);
				button_1.setBackground(clr);
			}
		});
		button_1.setBounds(975, 513, 179, 48);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);	
			}
		});
		button_1.setCursor(new Cursor(Cursor.HAND_CURSOR));
		button_1.setForeground(Color.WHITE);
		button_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		button_1.setBackground(new Color(255, 51, 153));
		panel.add(button_1);
		
		JLabel usericone = new JLabel("");
		usericone.setIcon(new ImageIcon(LogIn.class.getResource("/user.png")));
		usericone.setBackground(Color.WHITE);
		usericone.setBounds(766, 262, 56, 65);
		panel.add(usericone);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(LogIn.class.getResource("/pass1.png")));
		label.setBackground(Color.WHITE);
		label.setBounds(766, 377, 69, 65);
		panel.add(label);
		
		JLabel lblA = new JLabel("");
		lblA.setIcon(new ImageIcon(LogIn.class.getResource("/school.png")));
		lblA.setBounds(187, 188, 426, 406);
		panel.add(lblA);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblUsername.setForeground(new Color(255, 255, 255));
		lblUsername.setBounds(847, 245, 83, 24);
		panel.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPassword.setForeground(new Color(255, 255, 255));
		lblPassword.setBounds(847, 356, 83, 24);
		panel.add(lblPassword);
	}
}
