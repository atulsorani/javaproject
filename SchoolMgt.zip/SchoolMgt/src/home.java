import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.border.EtchedBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.ImageIcon;
import javax.swing.border.MatteBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class home {

	private JFrame home;
	private static JLabel DateTimel;
	private static JLabel timem;
	

	/**
	 * Launch the application.
	 */
	public static void Starthome() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					home window = new home();
					window.home.setVisible(true);
					CurDateTime();
					CurDaTime();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

	/**
	 * Create the application.
	 */
	public home() {
		initialize();
	}
	
	public static void CurDateTime() {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDateTime now = LocalDateTime.now();
			DateTimel.setText(dtf.format(now));
//			Tdate.setText(dtf.format(now));
	}
	
	public static void CurDaTime() {
		DateTimeFormatter dtff = DateTimeFormatter.ofPattern("hh : mm");
		LocalDateTime now = LocalDateTime.now();
		timem.setText(dtff.format(now));
}


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		home = new JFrame();
		home.setTitle("Welcome");
		home.setBounds(100, 100, 1400, 867);
		home.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		home.setResizable(false);
		home.setLocationRelativeTo(null);
		home.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBounds(12, 13, 1358, 794);
		home.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(102, 205, 170));
		panel_1.setBorder(new MatteBorder(2, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel_1.setBounds(0, 0, 1358, 145);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("STEP TO SUCCESS - SCHOOL");
		lblNewLabel.setBounds(313, 35, 818, 76);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("SansSerif", Font.BOLD, 50));
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(12, 0, 145, 145);
		lblNewLabel_1.setIcon(new ImageIcon(home.class.getResource("school3.png")));
		panel_1.add(lblNewLabel_1);
		
		DateTimel = new JLabel();
		DateTimel.setFont(new Font("Tahoma", Font.PLAIN, 17));
		DateTimel.setForeground(Color.WHITE);
		DateTimel.setBounds(1238, 35, 108, 38);
		panel_1.add(DateTimel);
		
		JLabel lblDate = new JLabel("Date : ");
		lblDate.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblDate.setForeground(Color.WHITE);
		lblDate.setBounds(1190, 47, 56, 16);
		panel_1.add(lblDate);
		
		timem = new JLabel("");
		timem.setFont(new Font("Tahoma", Font.PLAIN, 17));
		timem.setForeground(Color.WHITE);
		timem.setBounds(1248, 81, 90, 37);
		panel_1.add(timem);
		
		JLabel lblTime = new JLabel("Time - ");
		lblTime.setForeground(Color.WHITE);
		lblTime.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblTime.setBounds(1190, 92, 69, 16);
		panel_1.add(lblTime);
		
		JPanel panel_2 = new JPanel();
		panel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Student.StartStud();
			}
			@Override
			public void mouseEntered(MouseEvent arg0) {
				Color clr = new Color(0,128,106);
				panel_2.setBackground(clr);
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				Color clr = new Color(102,205,170);
				panel_2.setBackground(clr);
			}
		});
		panel_2.setCursor(new Cursor(Cursor.HAND_CURSOR));
		panel_2.setBorder(null );
		panel_2.setBackground(new Color(102, 205, 170));
		panel_2.setBounds(246, 238, 190, 190);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(31, 5, 128, 128);
		lblNewLabel_2.setIcon(new ImageIcon(home.class.getResource("/student.png")));
		panel_2.add(lblNewLabel_2);
		
		JLabel lblAddmition = new JLabel("Student");
		lblAddmition.setBounds(41, 130, 135, 34);
		lblAddmition.setFont(new Font("SansSerif", Font.BOLD, 26));
		lblAddmition.setForeground(Color.WHITE);
		panel_2.add(lblAddmition);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new EtchedBorder(EtchedBorder.RAISED, null, null));
		panel_3.setBackground(new Color(102, 205, 170));
		panel_3.setBounds(246, 521, 190, 190);
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(home.class.getResource("/teacher.png")));
		label_1.setBounds(36, 13, 142, 141);
		panel_3.add(label_1);
		
		JLabel lblTeacher = new JLabel("Teacher\r\ns");
		lblTeacher.setForeground(Color.WHITE);
		lblTeacher.setFont(new Font("SansSerif", Font.BOLD, 26));
		lblTeacher.setBounds(36, 148, 126, 29);
		panel_3.add(lblTeacher);
		
		JPanel panel_4 = new JPanel();
		panel_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				Color clr = new Color(0,128,106);
				panel_4.setBackground(clr);				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				Color clr = new Color(102,205,170);
				panel_4.setBackground(clr);
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				StudResult.StartStudRes();
			}
		});
		panel_4.setBorder(new EtchedBorder(EtchedBorder.RAISED, null, null));
		panel_4.setBackground(new Color(102, 205, 170));
		panel_4.setBounds(584, 238, 190, 190);
		panel_4.setCursor(new Cursor(Cursor.HAND_CURSOR));
		panel.add(panel_4);
		panel_4.setLayout(null);
		
		JLabel lblResult = new JLabel("Result");
		lblResult.setForeground(Color.WHITE);
		lblResult.setFont(new Font("SansSerif", Font.BOLD, 26));
		lblResult.setBounds(55, 143, 107, 34);
		panel_4.add(lblResult);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(home.class.getResource("/result.png")));
		lblNewLabel_3.setBounds(44, 13, 118, 132);
		panel_4.add(lblNewLabel_3);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBorder(new EtchedBorder(EtchedBorder.RAISED, null, null));
		panel_5.setBackground(new Color(102, 205, 170));
		panel_5.setBounds(584, 521, 190, 190);
		panel.add(panel_5);
		panel_5.setLayout(null);
		
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(home.class.getResource("/schedule.png")));
		label_2.setBounds(36, 0, 142, 141);
		panel_5.add(label_2);
		
		JLabel lblSchedule = new JLabel("Bonafide Cer");
		lblSchedule.setForeground(Color.WHITE);
		lblSchedule.setFont(new Font("SansSerif", Font.BOLD, 26));
		lblSchedule.setBounds(12, 148, 178, 29);
		panel_5.add(lblSchedule);
		
		JPanel panel_6 = new JPanel();
		panel_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				Color clr = new Color(0,128,106);
				panel_6.setBackground(clr);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				Color clr = new Color(102,205,170);
				panel_6.setBackground(clr);
			}
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Fees.Startfees();
			}
		});
		panel_6.setBorder(new EtchedBorder(EtchedBorder.RAISED, null, null));
		panel_6.setBackground(new Color(102, 205, 170));
		panel_6.setBounds(903, 238, 190, 190);
		panel_6.setCursor(new Cursor(Cursor.HAND_CURSOR));
		panel.add(panel_6);
		panel_6.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(home.class.getResource("/fees.png")));
		label.setBounds(47, 13, 118, 132);
		panel_6.add(label);
		
		JLabel lblAttendance = new JLabel("Fees");
		lblAttendance.setForeground(Color.WHITE);
		lblAttendance.setFont(new Font("SansSerif", Font.BOLD, 26));
		lblAttendance.setBounds(66, 145, 72, 34);
		panel_6.add(lblAttendance);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBorder(new EtchedBorder(EtchedBorder.RAISED, null, null));
		panel_7.setBackground(new Color(102, 205, 170));
		panel_7.setBounds(903, 521, 190, 190);
		panel.add(panel_7);
		panel_7.setLayout(null);
		
		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon(home.class.getResource("/event.png")));
		label_3.setBounds(51, 13, 118, 132);
		panel_7.add(label_3);
		
		JLabel lblEvent = new JLabel("Notice");
		lblEvent.setForeground(Color.WHITE);
		lblEvent.setFont(new Font("SansSerif", Font.BOLD, 26));
		lblEvent.setBounds(61, 143, 107, 34);
		panel_7.add(lblEvent);
		
		
	}
}
