import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.MatteBorder;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.Button;



public class LcCer {

	private JFrame LcCer;
	private JTextField txtid;
	private static JLabel Tdate;
	private static JLabel ttdate_1;
	private static JLabel TTdate;
	private JLabel txtnam;
	private JLabel txdob;
	private JLabel txadd;
	private JLabel adddate;
	private JLabel stdin;
	private JLabel adddate1;
	private JLabel adddate2;

	/**
	 * Launch the application.
	 */
	public static void StartLcCer() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LcCer window = new LcCer();
					window.LcCer.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LcCer() {
		initialize();
	}
	
	public static void CurDateTime() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDateTime now = LocalDateTime.now();
		Tdate.setText(dtf.format(now));
		ttdate_1.setText(dtf.format(now));
		TTdate.setText(dtf.format(now));
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		LcCer = new JFrame();
		LcCer.setTitle("LC certificate");
		LcCer.setBounds(100, 100, 1400, 867);
		LcCer.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		LcCer.setResizable(false);
		LcCer.setLocationRelativeTo(null);
		LcCer.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(12, 13, 1358, 794);
		LcCer.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 1358, 59);
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(102, 205, 170));
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblUpdateStudentsRecords = new JLabel("LC Certificate");
		lblUpdateStudentsRecords.setFont(new Font("SansSerif", Font.BOLD, 30));
		lblUpdateStudentsRecords.setForeground(Color.WHITE);
		lblUpdateStudentsRecords.setBounds(596, 13, 252, 33);
		panel_1.add(lblUpdateStudentsRecords);
		
		JLabel DateD = new JLabel("");
		DateD.setBounds(1121, 13, 169, 31);
		panel_1.add(DateD);
		
		JTextArea txtlc = new JTextArea();
		txtlc.setBounds(1014, 72, -520, 703);
		panel.add(txtlc);
		
		JPanel printlc = new JPanel();
		printlc.setBorder(null);
		printlc.setBackground(Color.WHITE);
		printlc.setBounds(514, 70, 495, 705);
		panel.add(printlc);
		printlc.setLayout(null);
		
		txtnam = new JLabel("");
		txtnam.setFont(new Font("Verdana", Font.BOLD, 17));
		txtnam.setBounds(149, 98, 271, 41);
		printlc.add(txtnam);
		
		txdob = new JLabel("");
		txdob.setFont(new Font("Verdana", Font.BOLD, 16));
		txdob.setBounds(198, 152, 153, 33);
		printlc.add(txdob);
		
		txadd = new JLabel("");
		txadd.setFont(new Font("Verdana", Font.BOLD, 16));
		txadd.setBounds(231, 198, 107, 33);
		printlc.add(txadd);
		
		
		
		Tdate = new JLabel("");
		Tdate.setFont(new Font("Verdana", Font.BOLD, 16));
		Tdate.setBounds(198, 532, 114, 23);
		printlc.add(Tdate);
		
		adddate = new JLabel("");
		adddate.setFont(new Font("Verdana", Font.BOLD, 16));
		adddate.setBounds(59, 310, 141, 33);
		printlc.add(adddate);
		
		stdin = new JLabel("");
		stdin.setFont(new Font("Verdana", Font.BOLD, 16));
		stdin.setBounds(316, 409, 78, 33);
		printlc.add(stdin);
		
		TTdate = new JLabel("");
		TTdate.setFont(new Font("SansSerif", Font.PLAIN, 15));
		TTdate.setBounds(132, 658, 131, 23);
		printlc.add(TTdate);
		
		ttdate_1 = new JLabel("");
		ttdate_1.setFont(new Font("Verdana", Font.BOLD, 16));
		ttdate_1.setBounds(349, 545, 114, 23);
		printlc.add(ttdate_1);
		
		adddate1 = new JLabel("");
		adddate1.setFont(new Font("Verdana", Font.BOLD, 16));
		adddate1.setBounds(46, 530, 122, 25);
		printlc.add(adddate1);
		
		adddate2 = new JLabel("");
		adddate2.setFont(new Font("Verdana", Font.BOLD, 15));
		adddate2.setBounds(324, 521, 114, 25);
		printlc.add(adddate2);
		
		JTextArea txtrTo = new JTextArea();
		txtrTo.setText("to");
		txtrTo.setBounds(443, 521, 20, 22);
		printlc.add(txtrTo);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(LcCer.class.getResource("LCcertificate.png")));
		label.setBounds(0, 0, 496, 709);
		printlc.add(label);
			
		txtid = new JTextField();
		txtid.setBounds(25, 88, 210, 41);
		panel.add(txtid);
		txtid.setColumns(10);
		
		JButton btnNewButton = new JButton("Get Details");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String idd = txtid.getText();
				txtid.requestFocus();
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgt","root","");
					Statement st=con.createStatement();
					String sql ="SELECT `id`, `name`, `dob`, `stdin`, `DofAdd` FROM `admission` WHERE id = '"+idd+"'";
					ResultSet rs = st.executeQuery(sql);
					if(rs.next()) {
						txtid.setText(rs.getString(1));
						txadd.setText(rs.getString(1));
						txtnam.setText(rs.getString(2));
						
						String ds1 = rs.getString(3);
						SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
						SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
						String ds2 = sdf2.format(sdf1.parse(ds1));
						txdob.setText(ds2);
						
						stdin.setText(rs.getString(4));
						
						String ds11 = rs.getString(5);
						SimpleDateFormat sdf11 = new SimpleDateFormat("yyyy-MM-dd");
						SimpleDateFormat sdf22 = new SimpleDateFormat("dd/MM/yyyy");
						String ds22 = sdf22.format(sdf11.parse(ds11));
						
						adddate.setText(ds22);
						adddate1.setText(ds22);
						adddate2.setText(ds22);
					
						CurDateTime();
						
					}
					
				} catch (ClassNotFoundException e) {
				
					e.printStackTrace();
				} catch (SQLException e) {
				
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
			}
		});
		btnNewButton.setFont(new Font("Verdana", Font.PLAIN, 13));
		btnNewButton.setBounds(284, 92, 107, 33);
		panel.add(btnNewButton);
		
		Button PrintBtn = new Button("DELETE");
		PrintBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String idd = txtid.getText();
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgt","root","");
					String sql = "DELETE FROM `admission` WHERE id = '"+idd+"'";
					PreparedStatement st=con.prepareStatement(sql);
					st.execute();
					JOptionPane.showMessageDialog(null, "Student's Record Deleted From DataBase....");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				
			}
		});
		PrintBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
		PrintBtn.setFont(new Font("Verdana", Font.BOLD, 20));
		PrintBtn.setBackground(new Color(199, 21, 133));
		PrintBtn.setForeground(new Color(255, 255, 255));
		PrintBtn.setBounds(1163, 668, 118, 41);
		panel.add(PrintBtn);
		
		JButton btnprint = new JButton("PRINT");
		btnprint.setBackground(new Color(102, 205, 170));
		btnprint.setForeground(Color.WHITE);
		btnprint.setFont(new Font("Verdana", Font.BOLD, 20));
		btnprint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				printRecord(printlc);
			}

			private void printRecord(JPanel printlc) {
				// TODO Auto-generated method stub
				PrinterJob printerJob = PrinterJob.getPrinterJob();
				printerJob.setJobName("Print Record");
				printerJob.setPrintable(new Printable() {
					
					@Override
					public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
						if(pageIndex > 0) {
							return Printable.NO_SUCH_PAGE;
						}
						Graphics2D graphics2D = (Graphics2D)graphics;
						graphics2D.translate(pageFormat.getImageableX()*2, pageFormat.getImageableY()*2);
						graphics2D.scale(1, 1);
						printlc.paint(graphics2D);
						
						return Printable.PAGE_EXISTS;
					}
				});
				boolean returningResult = printerJob.printDialog();
				if(returningResult) {
					try {
						printerJob.print();
						
					}catch(PrinterException e){
						JOptionPane.showMessageDialog(printlc, this, "Printer Error : " + e.getMessage(), 0, null);
						
					}
				}
			}
		});
		btnprint.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnprint.setBounds(1163, 534, 118, 41);
		panel.add(btnprint);
		
	
		
	
		
			
		
		
	}
}
