import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Student {

	private JFrame Stud;

	/**
	 * Launch the application.
	 */
	public static void StartStud() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student window = new Student();
					window.Stud.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Student() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Stud = new JFrame();
		Stud.getContentPane().setBackground(Color.WHITE);
		Stud.setTitle("Student");
		Stud.setBounds(100, 100, 1400, 867);
		Stud.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		Stud.setResizable(false);
		Stud.setLocationRelativeTo(null);
		Stud.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBounds(12, 13, 1358, 794);
		Stud.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(102, 205, 170));
		panel_1.setBorder(new MatteBorder(2, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel_1.setBounds(0, 0, 1358, 145);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("STEP TO SUCCESS - SCHOOL");
		lblNewLabel.setBounds(304, 32, 818, 76);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("SansSerif", Font.BOLD, 50));
		panel_1.add(lblNewLabel);
		

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(12, 0, 145, 145);
		lblNewLabel_1.setIcon(new ImageIcon(home.class.getResource("school3.png")));
		panel_1.add(lblNewLabel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Admission.startAdmission();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				Color clr = new Color(0,128,106);
				panel_2.setBackground(clr);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				Color clr = new Color(102,205,170);
				panel_2.setBackground(clr);
			}
		});
		panel_2.setCursor(new Cursor(Cursor.HAND_CURSOR));
		panel_2.setBackground(new Color(102, 205, 170));
		panel_2.setBounds(89, 305, 314, 314);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(Student.class.getResource("newadmission11.png")));
		lblNewLabel_2.setBounds(51, 13, 212, 206);
		panel_2.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("New \r\nAdmission");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("SansSerif", Font.BOLD, 30));
		lblNewLabel_3.setBounds(51, 234, 223, 40);
		panel_2.add(lblNewLabel_3);
		
		JPanel panel_3 = new JPanel();
		panel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				StudUpdate.StartStudUpdate();
			}
			public void mouseEntered(MouseEvent e) {
				Color clr = new Color(0,128,106);
				panel_3.setBackground(clr);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				Color clr = new Color(102,205,170);
				panel_3.setBackground(clr);
			}
		});
		panel_3.setCursor(new Cursor(Cursor.HAND_CURSOR));
		panel_3.setBackground(new Color(102, 205, 170));
		panel_3.setBounds(515, 305, 314, 314);
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Student.class.getResource("update.png")));
		label.setBounds(48, 13, 212, 206);
		panel_3.add(label);
		
		JLabel lblUpdateDetails = new JLabel("Update Student's");
		lblUpdateDetails.setForeground(Color.WHITE);
		lblUpdateDetails.setFont(new Font("SansSerif", Font.BOLD, 30));
		lblUpdateDetails.setBounds(33, 224, 269, 39);
		panel_3.add(lblUpdateDetails);
		
		JLabel lblDetails = new JLabel("Details");
		lblDetails.setForeground(Color.WHITE);
		lblDetails.setFont(new Font("SansSerif", Font.BOLD, 30));
		lblDetails.setBounds(99, 262, 111, 39);
		panel_3.add(lblDetails);
		
		JPanel panel_4 = new JPanel();
		panel_4.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				Color clr = new Color(0,128,106);
				panel_4.setBackground(clr);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				Color clr = new Color(102,205,170);
				panel_4.setBackground(clr);
			}
			@Override
			public void mouseClicked(MouseEvent arg0) {
				LcCer.StartLcCer();
			}
		});
		panel_4.setCursor(new Cursor(Cursor.HAND_CURSOR));
		panel_4.setBackground(new Color(102, 205, 170));
		panel_4.setBounds(946, 305, 314, 314);
		panel.add(panel_4);
		panel_4.setLayout(null);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(Student.class.getResource("lc.png")));
		label_1.setBounds(53, 13, 212, 206);
		panel_4.add(label_1);
		
		JLabel lblLcCertificate = new JLabel("LC certificate");
		lblLcCertificate.setForeground(Color.WHITE);
		lblLcCertificate.setFont(new Font("SansSerif", Font.BOLD, 30));
		lblLcCertificate.setBounds(65, 247, 212, 39);
		panel_4.add(lblLcCertificate);
		
		Button button = new Button("Increase Student's Class");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				Color clr = new Color(0,128,106);
				button.setBackground(clr);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				Color clr = new Color(102,205,170);
				button.setBackground(clr);
			}
		});
		button.setBackground(new Color(102, 205, 170));
		button.setFont(new Font("SansSerif", Font.BOLD, 20));
		button.setForeground(Color.WHITE);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int aa = JOptionPane.showConfirmDialog(null, "First You want to get LC certificate Student of class 12. Can you get?");
				if(aa==JOptionPane.NO_OPTION) {
					JOptionPane.showMessageDialog(null, "You can loss all records ablout Students of class 12");
					int a = JOptionPane.showConfirmDialog(null, "Are you sure ? You want to Increase Students Class ?");
					if(a==JOptionPane.YES_OPTION) {
						
						try {
							Class.forName("com.mysql.jdbc.Driver");
							Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgt","root","");
							String sqll = "UPDATE `admission` SET `stdin` = stdin + 1, `fees` =  'unpaid' ";
							PreparedStatement st=con.prepareStatement(sqll);
							st.executeUpdate();
							
							String sql = "DELETE FROM `admission` WHERE stdin = '"+12+"'";
							PreparedStatement stt=con.prepareStatement(sql);
							stt.execute();
													
						} catch (ClassNotFoundException e) {
							e.printStackTrace();
						} catch (SQLException e) {
							e.printStackTrace();
						}
						JOptionPane.showMessageDialog(null, "Class Increased .......");
						
					}
				}
				if(aa==JOptionPane.YES_OPTION) {
					LcCer.StartLcCer();
				}
			}
		});
		button.setCursor(new Cursor(Cursor.HAND_CURSOR));
		button.setBounds(515, 678, 314, 70);
		panel.add(button);
		
		
		
	}
}
