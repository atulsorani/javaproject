import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import java.awt.SystemColor;
import javax.swing.ButtonGroup;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;


public class Admission {

	private JFrame addstud;
	private JTextField txtname;
	private ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField txtmno;
	private JTextField txtid;
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void startAdmission() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admission window = new Admission();
					window.addstud.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Admission() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		addstud = new JFrame();
		addstud.setTitle("New Admission");
		addstud.setBounds(100, 100, 1400, 867);
		addstud.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		addstud.setResizable(false);
		addstud.setLocationRelativeTo(null);
		addstud.getContentPane().setLayout(null);

		
		JPanel panel = new JPanel();
		panel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		panel.setBackground(Color.WHITE);
		panel.setBounds(12, 13, 1358, 794);
		addstud.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(102, 205, 170));
		panel_1.setBounds(0, 0, 1358, 59);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Admission Form");
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD, 30));
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(567, 13, 360, 33);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNmae = new JLabel("Name");
		lblNmae.setFont(new Font("Verdana", Font.PLAIN, 17));
		lblNmae.setBounds(409, 159, 56, 16);
		panel.add(lblNmae);
		
		txtname = new JTextField();
		txtname.setFont(new Font("Verdana", Font.PLAIN, 17));
		txtname.setBounds(528, 153, 284, 34);
		panel.add(txtname);
		txtname.setColumns(10);
		
		JLabel lblDate = new JLabel("DOB");
		lblDate.setFont(new Font("Verdana", Font.PLAIN, 17));
		lblDate.setBounds(409, 226, 56, 16);
		panel.add(lblDate);
		
		JDateChooser txtdob = new JDateChooser();
		txtdob.setBounds(528, 218, 284, 34);
		panel.add(txtdob);
		
		JDateChooser addDate = new JDateChooser();
		addDate.setBounds(528, 358, 284, 34);
		panel.add(addDate);
		
		
		JLabel lblClassToBe = new JLabel("Admission in");
		lblClassToBe.setFont(new Font("Verdana", Font.PLAIN, 16));
		lblClassToBe.setBounds(409, 287, 107, 32);
		panel.add(lblClassToBe);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setFont(new Font("Verdana", Font.PLAIN, 17));
		lblGender.setBounds(409, 430, 84, 22);
		panel.add(lblGender);
	
		
		JRadioButton txtmale = new JRadioButton("MALE");
		buttonGroup.add(txtmale);
		txtmale.setFont(new Font("Tahoma", Font.PLAIN, 17));
		txtmale.setBounds(528, 424, 107, 34);
		panel.add(txtmale);
		
		JRadioButton txtfemale = new JRadioButton("FEMALE");
		buttonGroup.add(txtfemale);
		txtfemale.setFont(new Font("Tahoma", Font.PLAIN, 17));
		txtfemale.setBounds(705, 424, 107, 34);
		panel.add(txtfemale);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Verdana", Font.PLAIN, 17));
		lblAddress.setBounds(409, 554, 84, 27);
		panel.add(lblAddress);
		
		JTextArea txtaddress = new JTextArea();
		txtaddress.setFont(new Font("Verdana", Font.PLAIN, 17));
		txtaddress.setForeground(Color.BLACK);
		txtaddress.setBackground(SystemColor.controlHighlight);
		txtaddress.setRows(3);
		txtaddress.setBounds(528, 558, 284, 93);
		panel.add(txtaddress);
		

		JComboBox<String> stdin = new JComboBox<>();
		stdin.setFont(new Font("Verdana", Font.PLAIN, 17));
		stdin.setModel(new DefaultComboBoxModel<String>(new String[] {"Select your class", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		stdin.setBounds(528, 288, 284, 34);
		panel.add(stdin);
		
		
		JLabel lblMobileNo = new JLabel("Mobile No");
		lblMobileNo.setFont(new Font("Verdana", Font.PLAIN, 17));
		lblMobileNo.setBounds(409, 489, 107, 34);
		panel.add(lblMobileNo);
		
		txtmno = new JTextField();
		txtmno.setFont(new Font("Verdana", Font.PLAIN, 17));
		txtmno.setBounds(528, 489, 284, 34);
		panel.add(txtmno);
		txtmno.setColumns(10);
		
		JLabel lblReligion = new JLabel("Admission");
		lblReligion.setFont(new Font("Verdana", Font.PLAIN, 17));
		lblReligion.setBounds(409, 355, 97, 22);
		panel.add(lblReligion);
		
		JRadioButton rdbtnPaid = new JRadioButton("PAID");
		buttonGroup_1.add(rdbtnPaid);
		rdbtnPaid.setFont(new Font("Tahoma", Font.PLAIN, 17));
		rdbtnPaid.setBounds(528, 674, 107, 34);
		panel.add(rdbtnPaid);
		
		JRadioButton rdbtnUnpaid = new JRadioButton("UNPAID");
		buttonGroup_1.add(rdbtnUnpaid);
		rdbtnUnpaid.setFont(new Font("Tahoma", Font.PLAIN, 17));
		rdbtnUnpaid.setBounds(705, 674, 107, 34);
		panel.add(rdbtnUnpaid);
		
		JLabel lblFees = new JLabel("Fees");
		lblFees.setFont(new Font("Verdana", Font.PLAIN, 17));
		lblFees.setBounds(409, 680, 84, 22);
		panel.add(lblFees);
		
		Button btnsubmit = new Button("Submit");
		btnsubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
				
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgt","root","");
					String sqll = "INSERT INTO `admission`(`id`, `name`, `dob`, `stdin`, `gen`, `mobino`, `DofAdd`, `address`, `fees`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
					PreparedStatement st=con.prepareStatement(sqll);
					
					

					
					st.setString(1, txtid.getText());
					st.setString(2, txtname.getText());

					SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
					String date1 = sdf.format(txtdob.getDate());
					st.setString(3, date1);
					
					String val = stdin.getSelectedItem().toString();
					st.setString(4, val);
					
							String gen = null;
						if(txtmale.isSelected()) {
							 gen = "male";
						}
						else
						{
							gen = "female";
						}
						st.setString(5, gen);
					
						st.setString(6, txtmno.getText());
						
						SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
						String date11 = sdf1.format(addDate.getDate());
						st.setString(7, date11);
						
					
						st.setString(8, txtaddress.getText());
						String fee = null;
						if(rdbtnPaid.isSelected()) {
							 fee = "paid";
						}
						else
						{
							fee = "unpaid";
						}
						st.setString(9, fee);
						
						st.executeUpdate();
												
						JOptionPane.showMessageDialog(null, "Form Submited !!!");
						
						if(fee == "paid") {
							Fees.Startfees();
						}
						
						txtid.setText(null);
						txtname.setText(null);
						txtdob.setCalendar(null);
						stdin.setSelectedItem("Select your class");				
						buttonGroup.clearSelection();
						txtmno.setText(null);
						addDate.setCalendar(null);
						txtaddress.setText(null);
						buttonGroup_1.clearSelection();
				
					
				} catch (ClassNotFoundException e) {
					//JOptionPane.showMessageDialog(this, e.getMessage());
					e.printStackTrace();
				} catch (SQLException e) {
					//JOptionPane.showMessageDialog(null, e.getMessage());
					e.printStackTrace();
			}
							
			}
		});
		btnsubmit.setFont(new Font("Verdana", Font.PLAIN, 20));
		btnsubmit.setForeground(Color.WHITE);
		btnsubmit.setBackground(new Color(100, 149, 237));
		btnsubmit.setBounds(883, 728, 143, 43);
		panel.add(btnsubmit);
		
		Button btnclr = new Button("Clear");
		btnclr.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtid.setText(null);
				txtname.setText(null);
				txtdob.setCalendar(null);
				stdin.setSelectedItem("Select your class");				
				buttonGroup.setSelected(null, false);
				txtmno.setText(null);
				addDate.setCalendar(null);
				txtaddress.setText(null);
			}
		});
		btnclr.setFont(new Font("Verdana", Font.PLAIN, 20));
		btnclr.setForeground(Color.WHITE);
		btnclr.setBackground(new Color(255, 20, 147));
		btnclr.setBounds(350, 728, 143, 43);
		panel.add(btnclr);
		
		txtid = new JTextField();
		txtid.setEditable(false);
		txtid.setFont(new Font("Verdana", Font.PLAIN, 17));
		txtid.setBounds(528, 90, 284, 34);
		panel.add(txtid);
		txtid.setColumns(10);
		
		JButton btnGetId = new JButton("get id");
		btnGetId.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgt","root","");
					Statement stt=conn.createStatement();
					String sqll = "select id from admission";
					ResultSet rs = stt.executeQuery(sqll);
					rs.last();
					String i = (rs.getString(1));
					int inum = Integer.parseInt(i);
					int p = inum + 1;
					String s=String.valueOf(p);
					txtid.setText(s);
					
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
					
				
				
				
			}
		});
		btnGetId.setBounds(871, 95, 97, 25);
		panel.add(btnGetId);
		
		JLabel lblNewLabel = new JLabel("I'd");
		lblNewLabel.setFont(new Font("Verdana", Font.PLAIN, 17));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBounds(409, 99, 56, 16);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Date");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_2.setBounds(460, 376, 56, 16);
		panel.add(lblNewLabel_2);
		
		
		
		
		
		
	}
}
