import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.MatteBorder;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import java.awt.Button;


public class StudResult {

	private JFrame Sresult;
	private JTable table;
	private JTextField rs_id;
	public static String iddd = null;

	/**
	 * Launch the application.
	 */
	public static void StartStudRes() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudResult window = new StudResult();
					window.Sresult.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudResult() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Sresult = new JFrame();
		Sresult.setTitle("Student Result");
		Sresult.setBounds(100, 100, 1400, 867);
		Sresult.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		Sresult.setResizable(false);
		Sresult.setLocationRelativeTo(null);
		Sresult.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(12, 13, 1358, 794);
		Sresult.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(102, 205, 170));
		panel_1.setBounds(0, 0, 1358, 59);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel txthead = new JLabel("Student's Results");
		txthead.setFont(new Font("SansSerif", Font.BOLD, 30));
		txthead.setForeground(Color.WHITE);
		txthead.setBounds(546, 13, 476, 33);
		panel_1.add(txthead);
		
		JComboBox<String> comboBox = new JComboBox<>();
		comboBox.setFont(new Font("Verdana", Font.PLAIN, 20));
		comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"Select class", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		comboBox.setBounds(339, 145, 252, 39);
		panel.add(comboBox);
		
		JButton btnNewButton = new JButton("Get Records");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String val = comboBox.getSelectedItem().toString();
							
				try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgt","root","");
					Statement st=con.createStatement();
					String sqll = "SELECT * FROM `admission` WHERE `stdin` = '" + val + "'";
					ResultSet rs = st.executeQuery(sqll);
					
					while(rs.next()) {
						String id = String.valueOf(rs.getInt(1));
						String name = rs.getString(2);
						String dob = rs.getString(3);
						String stdin = rs.getString(4);
						String gen = rs.getString(5);
						String mobino = rs.getString(6);
						String DofAdd = rs.getString(7);
						String address = rs.getString(8);
						String fees = rs.getString(9);
						
						String tbData[] = {id,name,dob,stdin,gen,mobino,DofAdd,address,fees};
						DefaultTableModel tbl = (DefaultTableModel)table.getModel();
						tbl.addRow(tbData);
					}
					
					
					
				}catch (ClassNotFoundException e) {
					//JOptionPane.showMessageDialog(null, e);
					e.printStackTrace();
				} catch (SQLException e) {
					//JOptionPane.showMessageDialog(null, e.getMessage());
					e.printStackTrace();
			}
			}
		});
		btnNewButton.setFont(new Font("Yu Gothic UI", Font.BOLD, 16));
		btnNewButton.setBounds(727, 145, 126, 39);
		panel.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(121, 292, 1114, 197);
		panel.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setFont(new Font("Tahoma", Font.PLAIN, 15));
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"id", "name", "dob", "stdin", "gen", "mobino", "DofAdd", "address", "fees"
			}
		));
		table.getColumnModel().getColumn(0).setMinWidth(50);
		
		rs_id = new JTextField();
		rs_id.setFont(new Font("Verdana", Font.PLAIN, 17));
		rs_id.setBounds(426, 647, 165, 39);
		panel.add(rs_id);
		rs_id.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Enter Id");
		lblNewLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
		lblNewLabel.setBounds(426, 581, 110, 36);
		panel.add(lblNewLabel);
		
		Button button = new Button("Set Result");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			iddd = rs_id.getText();
				
				Stud_res.Startstud_res();
			}
		});
		button.setForeground(new Color(255, 255, 255));
		button.setCursor(new Cursor(Cursor.HAND_CURSOR));
		button.setFont(new Font("Verdana", Font.PLAIN, 18));
		button.setBackground(new Color(100, 149, 237));
		button.setBounds(727, 627, 156, 59);
		panel.add(button);
		
	}
}
