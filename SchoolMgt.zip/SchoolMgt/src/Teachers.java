import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.MatteBorder;

public class Teachers {

	private JFrame teacher;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Teachers window = new Teachers();
					window.teacher.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Teachers() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		teacher = new JFrame();
		teacher.setTitle("Teachers Detais");
		teacher.setBounds(100, 100, 1400, 867);
		teacher.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		teacher.setResizable(false);
		teacher.setLocationRelativeTo(null);
		teacher.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(12, 13, 1358, 794);
		teacher.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(102, 205, 170));
		panel_1.setBounds(0, 0, 1358, 59);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel txthead = new JLabel("Teachers Details");
		txthead.setFont(new Font("SansSerif", Font.BOLD, 30));
		txthead.setForeground(Color.WHITE);
		txthead.setBounds(559, 13, 476, 33);
		panel_1.add(txthead);
	}

}
